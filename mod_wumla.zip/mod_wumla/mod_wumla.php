<?php
/*
* @package WuBook Reception's Module
* @copyright Copyright (C) 2010 WuBook Srl. All rights reserved.
* @license http://www.Joomla.org/ GNU/GPL, see LICENSE.php
* Joomla! is free software.
* This extension is made for Joomla! 1.6+;
*/

defined('_JEXEC') or die('Restricted access');

$wu_snippet_last_update = $params->get( 'wu_snippet_last_update' );
$wu_update = $params->get( 'wu_update' );

if($wu_update == 1 || (time() - $wu_snippet_last_update) > 2592000) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://wubook.net/wbkd/xwidget/gen.html');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, true);
    $data = array(
	'lcode'         => $params->get( 'wu_lcode' ),
	'wtype'         => 'design_widget', # design_widget | design_iframe
	'wdivid'        => '__wubookwidget__', # (default= _wbord_)
	'width'         => $params->get( 'wu_width' ),
	'height'        => $params->get( 'wu_height' ),
	'email'         => (($params->get( 'wu_email' ) == '')?1:0),
	'cancel'        => (($params->get( 'wu_cancel' ) == '')?1:0),
	'lang'          => $params->get( 'wu_lang' ),
	'dates'         => (($params->get( 'wu_dates' ) == '')?1:0),
	'failback_lang' => $params->get( 'wu_failback_lang' ),
	'bgcolor'       => $params->get( 'wu_bgcolor' ),
	'textcolor'     => $params->get( 'wu_textcolor' ),
	'cards'         => (($params->get( 'wu_cards' ) == '')?1:0),
	'wbgoogle'      => (($params->get( 'wu_wbgoogle' ) == '')?1:0),
	'bestprice'     => (($params->get( 'wu_bestprice' ) == '')?1:0),
	'bids'          => (($params->get( 'wu_bids' ) == '')?1:0),
	'layout'        => $params->get( 'wu_layout' ),
	'css'           => $params->get( 'wu_css' )
    );
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $wu_get_widget = curl_exec($ch);
    #$info = curl_getinfo($ch);
    curl_close($ch);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://wubook.net/wbkd/xwidget/gen.html');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, true);
    $data = array(
	'lcode'    => $params->get( 'wu_lcode' ),
	'wtype'    => 'design_iframe', #design_widget | design_iframe
	'wdivid'   => '__wubookiframe__', # (default= _wbord_)
	'width'    => '#####width#####',
	'height'   => '#####height#####',
	'layout'   => $params->get( 'wu_layout' )
    );
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $wu_get_iframe = curl_exec($ch);
    #$info = curl_getinfo($ch);
    curl_close($ch);

    $wu_db = JFactory::getDbo();
    $wu_q = JFactory::getDBO()->getQuery(true);
    $wu_query = 'SELECT params FROM #__modules WHERE module="mod_wumla"';
    $wu_db->setQuery($wu_query);
    $wu_params = $wu_db->loadObjectList();
    $wu_options = json_decode($wu_params[0]->params, true);
    $wu_time = time();
    $wu_options['wu_snippet_last_update'] = "{$wu_time}";
    $wu_options['wu_snippet_widget'] = $wu_get_widget;
    $wu_options['wu_snippet_iframe'] = $wu_get_iframe;
    $wu_options['wu_update'] = 0;
    $wu_new_params = json_encode($wu_options);
    $wu_q->clear()
	 ->update('#__modules')
	 ->set('params = ' . $wu_db->quote($wu_new_params))
	 ->where('module = "mod_wumla"');
    $wu_db->setQuery($wu_q);
    $wu_db->execute();

    $html = $wu_get_widget;
} else {
    $html = $params->get( 'wu_snippet_widget' );
}

echo $html;
?>