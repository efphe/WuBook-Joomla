<?php
/**
* Plugin "WuBook Reception in Content" Realizzato da Eugenio Palumbo (steel@wubook.net) per WuBook s.r.l. (http://en.wubook.net)
*/

defined('_JEXEC') or die;

class plgContentPlg_Wumla extends JPlugin {
    var $plg_tag = "wbiframe"; // Contiene la stringa da ricercare nel content

    public function __construct(& $subject, $config) {
	parent::__construct($subject, $config);
	$this->loadLanguage();
    }

    function onContentPrepare($context, &$row, &$params, $page = 0) {
	$app = JFactory::getApplication();

	// cerco l'espressione all'interno del content
	$regex = "/{" . $this->plg_tag . "}/i";
	preg_match_all($regex,$row->text,$matches);

	$count = count($matches[0]); // Numero di occorrenze
	if(!$count) return; // Se non ci sono occorrenze della stringa termino l'esecuzione del plugin

	jimport( 'joomla.application.module.helper' );
	$mod_wumla = JModuleHelper::getModule( 'wumla' );
	if(is_object($mod_wumla)) {
	    // Recupero dei parametri
	    $db = JFactory::getDbo(); // Get the database instance
	    $query = $db->getQuery(true);
	    $query->select(array('params'));
	    $query->from($db->getPrefix() . 'modules');
	    $query->where('module="mod_wumla"');
	    $db->setQuery($query);
	    $p_ms = $db->loadObjectList();
	    $p_params = json_decode($p_ms[0]->params, true);

	    $wu_snippet_last_update = $p_params['wu_snippet_last_update'];
	    $wu_update = $p_params['wu_update'];

	    if($wu_update == 1 || (time() - $wu_snippet_last_update) > 2592000) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://wubook.net/wbkd/xwidget/gen.html');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, true);
		$data = array(
		    'lcode'         => $p_params['wu_lcode'],
		    'wtype'         => 'design_widget', # design_widget | design_iframe
		    'wdivid'        => '__wubookwidget__', # (default= _wbord_)
		    'width'         => $p_params['wu_width'],
		    'height'        => $p_params['wu_height'],
		    'email'         => $p_params['wu_email'],
		    'cancel'        => $p_params['wu_cancel'],
		    'lang'          => $p_params['wu_lang'],
		    'dates'         => $p_params['wu_dates'],
		    'failback_lang' => $p_params['wu_failback_lang'],
            'nights'        => $p_params['wu_nights'],
		    'dcode'         => $p_params['wu_dcode'],
		    'bgcolor'       => $p_params['wu_bgcolor'],
		    'textcolor'     => $p_params['wu_textcolor'],
		    'cards'         => $p_params['wu_cards'],
		    'wbgoogle'      => $p_params['wu_wbgoogle'],
		    'bestprice'     => $p_params['wu_bestprice'],
		    'bids'          => $p_params['wu_bids'],
		    'layout'        => $p_params['wu_layout'],
		    'css'           => $p_params['wu_css']
		);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$wu_get_widget = curl_exec($ch);
		#$info = curl_getinfo($ch);
		curl_close($ch);

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://wubook.net/wbkd/xwidget/gen.html');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, true);
		$data = array(
		    'lcode'    => $p_params['wu_lcode'],
		    'wtype'    => 'design_iframe', #design_widget | design_iframe
		    'wdivid'   => '__wubookiframe__', # (default= _wbord_)
		    'width'    => '#####width#####',
		    'height'   => '#####height#####',
		    'layout'   => $p_params['wu_layout']
		);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$wu_get_iframe = curl_exec($ch);
		#$info = curl_getinfo($ch);
		curl_close($ch);

		$wu_db = JFactory::getDbo();
		$wu_q = JFactory::getDBO()->getQuery(true);
		$wu_query = 'SELECT params FROM #__modules WHERE module="mod_wumla"';
		$wu_db->setQuery($wu_query);
		$wu_params = $wu_db->loadObjectList();
		$wu_options = json_decode($wu_params[0]->params, true);
		$wu_time = time();
		$wu_options['wu_snippet_last_update'] = "{$wu_time}";
		$wu_options['wu_snippet_widget'] = $wu_get_widget;
		$wu_options['wu_snippet_iframe'] = $wu_get_iframe;
		$wu_options['wu_update'] = 0;
		$wu_new_params = json_encode($wu_options);
		$wu_q->clear()
		    ->update('#__modules')
		    ->set('params = ' . $wu_db->quote($wu_new_params))
		    ->where('module = "mod_wumla"');
		$wu_db->setQuery($wu_q);
		$wu_db->execute();

		$plg_output = $wu_get_iframe;
	    } else {
		$plg_output = $p_params['wu_snippet_iframe'];
	    }
	    $plg_output = str_replace('#####width#####', $p_params['wu_width_iframe'], $plg_output);
	    $plg_output = str_replace('#####height#####', $p_params['wu_height_iframe'], $plg_output);

	} elseif($mod_wumla === NULL) {
	    echo '<!-- Module mod_wumla is not active -->';
	    $plg_output = '';
	}

	$row->text = preg_replace( $regex, $plg_output , $row->text );
    }
}